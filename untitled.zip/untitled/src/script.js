function calculateTotal() {
  let inputs = document.querySelectorAll("input[type='number']");
  let orderDetails = "";
  let total = 0;

  inputs.forEach(input => {
    let qty = parseInt(input.value);
    if (qty > 0) {
      let price = parseInt(input.getAttribute("data-price"));
      let item = input.getAttribute("data-item");
      let cost = qty * price;

      orderDetails += `${item} x ${qty} = ₹${cost}<br>`;
      total += cost;
    }
  });

  if (total > 0) {
    document.getElementById("orderDetails").innerHTML = orderDetails;
    document.getElementById("totalAmount").innerText = "Total: ₹" + total;
  } else {
    document.getElementById("orderDetails").innerHTML = "No items selected.";
    document.getElementById("totalAmount").innerText = "";
  }
}